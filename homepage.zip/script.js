function index() {
    window.location.href = 'index.html';
}
function about() {
    window.location.href = 'about.html';
}
function puzzles() {
    window.location.href = 'puzzles.html';
}
